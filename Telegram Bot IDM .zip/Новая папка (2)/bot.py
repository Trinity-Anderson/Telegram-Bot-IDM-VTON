import os
os.environ["GRADIO_CLIENT_TIMEOUT"] = "1200"  # 20 минут, можно больше

import json
from io import BytesIO
from pathlib import Path
from typing import Dict, Any, Optional
import asyncio
from threading import Lock
import tempfile

from dotenv import load_dotenv
from gradio_client import Client, handle_file as gradio_file

from aiogram import Bot, Dispatcher, F, Router
from aiogram.filters import CommandStart, Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    Message,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    BufferedInputFile,
)

# ===================== НАСТРОЙКИ И ХРАНИЛИЩА =====================

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
if not BOT_TOKEN:
    raise RuntimeError("Не задан BOT_TOKEN в .env")

SUPER_ADMIN_ID_STR = os.getenv("SUPER_ADMIN_ID")
if not SUPER_ADMIN_ID_STR:
    raise RuntimeError("Не задан SUPER_ADMIN_ID в .env")
SUPER_ADMIN_ID = int(SUPER_ADMIN_ID_STR)

SETTINGS_FILE = Path("settings.json")
PRODUCTS_FILE = Path("products.json")

# По умолчанию используем levihsu/OOTDiffusion
IDM_VTON_SPACE = os.getenv("IDM_VTON_SPACE", "levihsu/OOTDiffusion")
HF_TOKEN = os.getenv("HF_TOKEN", None)  # если Space приватный


def load_settings() -> Dict[str, Any]:
    if SETTINGS_FILE.exists():
        with SETTINGS_FILE.open("r", encoding="utf-8") as f:
            data = json.load(f)
    else:
        data = {}

    data.setdefault("channel_id", None)
    data.setdefault("admin_ids", [SUPER_ADMIN_ID])
    data.setdefault("ai_api_url", "")
    data.setdefault("ai_api_key", "")
    data.setdefault(
        "prompt_try_on",
        "Надень указанный мерч (одежду) на человека с фотографии. "
        "Сделай реалистичную примерку, сохрани пропорции тела и естественное освещение.",
    )

    if SUPER_ADMIN_ID not in data["admin_ids"]:
        data["admin_ids"].append(SUPER_ADMIN_ID)

    save_settings(data)
    return data


def save_settings(data: Dict[str, Any]) -> None:
    with SETTINGS_FILE.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def load_products() -> Dict[str, Any]:
    if PRODUCTS_FILE.exists():
        with PRODUCTS_FILE.open("r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_products(data: Dict[str, Any]) -> None:
    with PRODUCTS_FILE.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


SETTINGS: Dict[str, Any] = load_settings()
PRODUCTS: Dict[str, Any] = load_products()


def get_next_product_id() -> str:
    if not PRODUCTS:
        return "1"
    max_id = max(int(k) for k in PRODUCTS.keys())
    return str(max_id + 1)


def is_admin(user_id: int) -> bool:
    return (user_id == SUPER_ADMIN_ID) or (user_id in SETTINGS.get("admin_ids", []))


# ===================== FSM СОСТОЯНИЯ =====================

class TryOnStates(StatesGroup):
    waiting_for_user_photo = State()


class AdminStates(StatesGroup):
    waiting_for_channel = State()
    waiting_for_prompt_try_on = State()


# ===================== ИНИЦИАЛИЗАЦИЯ БОТА =====================

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())
router = Router()
dp.include_router(router)


# ===================== КЛИЕНТ OOTDiffusion (Gradio API) =====================

_idm_client: Optional[Client] = None
_tryon_lock = Lock()


def get_idm_client() -> Client:
    """
    Ленивая инициализация клиента Gradio для Space levihsu/OOTDiffusion.
    """
    global _idm_client
    if _idm_client is None:
        if HF_TOKEN:
            _idm_client = Client(IDM_VTON_SPACE, hf_token=HF_TOKEN)
        else:
            _idm_client = Client(IDM_VTON_SPACE)
    return _idm_client


def call_ai_try_on(merch_bytes: bytes, user_bytes: bytes, garment_des: str = "clothes") -> bytes:
    """
    Вызывает OOTDiffusion (levihsu/OOTDiffusion) через gradio_client.

    Используем endpoint /process_dc (Disentangled Control) с категорией "Upper-body":
    - vton_img  — фото человека (user_bytes)
    - garm_img  — фото одежды (merch_bytes)
    """
    client = get_idm_client()  # Client("levihsu/OOTDiffusion")

    user_path = ""
    merch_path = ""
    result_paths = []

    try:
        # 1. Сохраняем мерч и фото пользователя во временные файлы
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f_user:
            f_user.write(user_bytes)
            f_user.flush()
            user_path = f_user.name

        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f_merch:
            f_merch.write(merch_bytes)
            f_merch.flush()
            merch_path = f_merch.name

        # 2. Один синхронный вызов к OOTDiffusion
        with _tryon_lock:
            result = client.predict(
                vton_img=gradio_file(user_path),
                garm_img=gradio_file(merch_path),
                category="Upper-body",  # "Upper-body", "Lower-body", "Dress"
                n_samples=1,
                n_steps=20,
                image_scale=2,
                seed=-1,
                api_name="/process_dc",
            )

        # result: List[Dict(image: filepath, caption: str | None)]
        if not isinstance(result, list) or len(result) == 0:
            raise RuntimeError(f"OOTDiffusion вернул пустой результат: {result}")

        first_item = result[0]
        if not isinstance(first_item, dict) or "image" not in first_item:
            raise RuntimeError(f"OOTDiffusion вернул неожиданный формат: {result}")

        out_image_path = first_item["image"]
        result_paths.append(out_image_path)

        if not out_image_path or not os.path.exists(out_image_path):
            raise RuntimeError(f"OOTDiffusion вернул некорректный путь к файлу: {out_image_path}")

        # 3. Читаем байты итогового изображения
        with open(out_image_path, "rb") as f:
            img_bytes = f.read()

        return img_bytes

    except Exception as e:
        raise RuntimeError(f"Ошибка вызова OOTDiffusion: {e}")

    finally:
        # Чистим все временные файлы
        for p in [user_path, merch_path] + result_paths:
            if p and os.path.exists(p):
                try:
                    os.remove(p)
                except Exception:
                    pass


# ===================== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ БОТА =====================

async def download_file_bytes(file_id: str) -> bytes:
    from aiogram.types import File
    file_obj: File = await bot.get_file(file_id)
    buffer = BytesIO()
    await bot.download(file_obj, destination=buffer)
    return buffer.getvalue()


def build_try_on_button(product_id: str, bot_username: str) -> InlineKeyboardMarkup:
    deep_link = f"https://t.me/{bot_username}?start=prod_{product_id}"
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="Примерить", url=deep_link)]]
    )
    return keyboard


# ===================== ОБЩИЕ КОМАНДЫ =====================

@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    await state.clear()

    args = message.text.split(maxsplit=1)
    if len(args) == 1:
        await message.answer(
            "Привет! Это бот примерки мерча.\n\n"
            "1. Зайдите в наш канал.\n"
            "2. Под мерчем нажмите кнопку «Примерить».\n"
            "3. Вас перебросит сюда — бот попросит ваше фото и вернёт результат.\n\n"
            "Если вы админ, введите /settings для настройки бота."
        )
        return

    param = args[1].strip()
    if not param.startswith("prod_"):
        await message.answer(
            "Параметр старта не распознан. "
            "Перейдите через кнопку «Примерить» под постом в канале."
        )
        return

    product_id = param.replace("prod_", "", 1)
    product = PRODUCTS.get(product_id)
    if not product:
        await message.answer("Этот мерч не найден. Возможно, он был удалён.")
        return

    await state.update_data(
        product_id=product_id,
        merch_file_id=product["file_id"],
    )
    await state.set_state(TryOnStates.waiting_for_user_photo)

    title = product.get("title") or f"Мерч #{product_id}"

    caption_text = (
        f"Вы выбрали: {title}\n\n"
        "Теперь отправьте *своё фото*, на которое нужно примерить этот мерч.\n"
        "Лучше всего: фото по пояс, анфас, хорошее освещение."
    )

    await message.answer_photo(
        photo=product["file_id"],
        caption=caption_text,
        parse_mode="Markdown",
    )


@router.message(Command("whoami"))
async def cmd_whoami(message: Message):
    await message.answer(
        f"Ваш Telegram ID: `{message.from_user.id}`",
        parse_mode="Markdown",
    )


# ===================== АДМИНСКИЕ КОМАНДЫ: НАСТРОЙКИ =====================

@router.message(Command("settings"))
async def cmd_settings(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer("Эта команда доступна только администраторам.")
        return

    channel_id = SETTINGS.get("channel_id")
    ai_url = SETTINGS.get("ai_api_url") or "не используется (прямая интеграция с OOTDiffusion Space)"
    ai_key = SETTINGS.get("ai_api_key")
    prompt = SETTINGS.get("prompt_try_on") or ""

    admins = SETTINGS.get("admin_ids", [])
    admins_str = ", ".join(str(a) for a in admins)

    text = (
        "*Текущие настройки:*\n\n"
        f"*Канал:* `{channel_id}`\n"
        f"*AI URL:* `{ai_url}`\n"
        f"*AI KEY задан:* {'да' if ai_key else 'нет'}\n"
        f"*Промпт (примерка мерча):* `{prompt}`\n\n"
        f"*Админы (ID):* {admins_str}\n\n"
        "Команды для настройки:\n"
        "`/set_channel` — выбрать канал (перешлите сообщение из канала или введите ID)\n"
        "`/set_prompt` — изменить текст промпта для примерки (для будущего API)\n"
        "`/admins` — показать админов\n"
        "`/add_admin <id>` — добавить админа\n"
        "`/del_admin <id>` — удалить админа\n"
        "`/add_product` — добавить пост с мерчем и опубликовать в канале"
    )

    await message.answer(text, parse_mode="Markdown")


@router.message(Command("admins"))
async def cmd_admins(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer("Эта команда доступна только администраторам.")
        return

    admins = SETTINGS.get("admin_ids", [])
    text = "Список админов (ID):\n" + "\n".join(f"- `{a}`" for a in admins)
    await message.answer(text, parse_mode="Markdown")


@router.message(Command("add_admin"))
async def cmd_add_admin(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer("Эта команда доступна только администраторам.")
        return

    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        await message.answer("Использование: `/add_admin <telegram_id>`", parse_mode="Markdown")
        return

    try:
        new_id = int(parts[1])
    except ValueError:
        await message.answer("ID должен быть числом.")
        return

    admins = SETTINGS.get("admin_ids", [])
    if new_id in admins:
        await message.answer("Этот пользователь уже в списке админов.")
        return

    admins.append(new_id)
    SETTINGS["admin_ids"] = admins
    save_settings(SETTINGS)

    await message.answer(f"Пользователь {new_id} добавлен в админы.")


@router.message(Command("del_admin"))
async def cmd_del_admin(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer("Эта команда доступна только администраторам.")
        return

    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        await message.answer("Использование: `/del_admin <telegram_id>`", parse_mode="Markdown")
        return

    try:
        del_id = int(parts[1])
    except ValueError:
        await message.answer("ID должен быть числом.")
        return

    if del_id == SUPER_ADMIN_ID:
        await message.answer("Нельзя удалить главного админа (SUPER_ADMIN_ID).")
        return

    admins = SETTINGS.get("admin_ids", [])
    if del_id not in admins:
        await message.answer("Этот пользователь не в списке админов.")
        return

    admins.remove(del_id)
    SETTINGS["admin_ids"] = admins
    save_settings(SETTINGS)

    await message.answer(f"Пользователь {del_id} удалён из админов.")


# ---- Настройка канала ----

@router.message(Command("set_channel"))
async def cmd_set_channel(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        await message.answer("Эта команда доступна только администраторам.")
        return

    await state.set_state(AdminStates.waiting_for_channel)
    await message.answer(
        "Перешлите сюда *любое сообщение* из канала, где будут посты с мерчем, "
        "или отправьте его ID (например: `-1001234567890`).",
        parse_mode="Markdown",
    )


@router.message(AdminStates.waiting_for_channel)
async def handle_set_channel(message: Message, state: FSMContext):
    if message.forward_from_chat and message.forward_from_chat.type == "channel":
        chat_id = message.forward_from_chat.id
        SETTINGS["channel_id"] = chat_id
        save_settings(SETTINGS)
        await state.clear()
        await message.answer(f"ID канала сохранён: `{chat_id}`", parse_mode="Markdown")
        return

    if message.text:
        txt = message.text.strip()
        if txt.lstrip("-").isdigit():
            chat_id = int(txt)
            SETTINGS["channel_id"] = chat_id
            save_settings(SETTINGS)
            await state.clear()
            await message.answer(f"ID канала сохранён: `{chat_id}`", parse_mode="Markdown")
            return

    await message.answer(
        "Не удалось определить канал.\n"
        "Перешлите сообщение из канала или введите его числовой ID.",
    )


# ---- Настройка промпта ----

@router.message(Command("set_prompt"))
async def cmd_set_prompt(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        await message.answer("Эта команда доступна только администраторам.")
        return

    cur_prompt = SETTINGS.get("prompt_try_on") or ""
    await state.set_state(AdminStates.waiting_for_prompt_try_on)
    await message.answer(
        "Отправьте новый текст промпта для *примерки мерча*.\n\n"
        f"Сейчас промпт:\n`{cur_prompt}`",
        parse_mode="Markdown",
    )


@router.message(AdminStates.waiting_for_prompt_try_on)
async def handle_set_prompt(message: Message, state: FSMContext):
    if not message.text:
        await message.answer("Ожидаю текст промпта.")
        return

    prompt = message.text.strip()
    SETTINGS["prompt_try_on"] = prompt
    save_settings(SETTINGS)
    await state.clear()
    await message.answer(
        "Промпт для примерки мерча сохранён.\n"
        f"Новый промпт:\n`{prompt}`",
        parse_mode="Markdown",
    )


# ===================== АДМИН: ДОБАВЛЕНИЕ МЕРЧА =====================

@router.message(Command("add_product"))
async def cmd_add_product(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer("Эта команда доступна только администраторам.")
        return

    channel_id = SETTINGS.get("channel_id")
    if not channel_id:
        await message.answer(
            "Канал пока не настроен. Сначала вызовите /set_channel и выберите канал."
        )
        return

    await message.answer(
        "Отправьте фото мерча (одежда и т.п., можно с подписью). "
        "Бот сохранит его и опубликует в канале с кнопкой «Примерить»."
    )


@router.message(F.photo, StateFilter(None))
async def handle_new_product_photo(message: Message):
    """
    Фото от админа, когда нет активного состояния — считаем новым мерчем.
    """
    if not is_admin(message.from_user.id):
        return

    channel_id = SETTINGS.get("channel_id")
    if not channel_id:
        await message.answer("Канал пока не настроен. Сначала вызовите /set_channel.")
        return

    photo = message.photo[-1]
    file_id = photo.file_id
    title = message.caption or ""

    product_id = get_next_product_id()
    PRODUCTS[product_id] = {
        "file_id": file_id,
        "title": title,
    }
    save_products(PRODUCTS)

    me = await bot.get_me()
    keyboard = build_try_on_button(product_id, me.username)

    await bot.send_photo(
        chat_id=channel_id,
        photo=file_id,
        caption=title or f"Мерч #{product_id}",
        reply_markup=keyboard,
    )

    await message.answer(
        f"Мерч сохранён под номером {product_id} и опубликован в канале ✅"
    )


# ===================== ПОЛЬЗОВАТЕЛЬ: ФОТО ДЛЯ ПРИМЕРКИ =====================

@router.message(TryOnStates.waiting_for_user_photo)
async def handle_user_photo(message: Message, state: FSMContext):
    file_id = None

    if message.photo:
        file_id = message.photo[-1].file_id
    elif message.document and message.document.mime_type and message.document.mime_type.startswith("image/"):
        file_id = message.document.file_id

    if not file_id:
        await message.answer(
            "Пожалуйста, пришлите *фото* или *файл с изображением* для примерки.",
            parse_mode="Markdown",
        )
        return

    data = await state.get_data()
    merch_file_id = data.get("merch_file_id")
    product_id = data.get("product_id")

    if not merch_file_id or not product_id:
        await message.answer(
            "Не удалось определить выбранный мерч. "
            "Попробуйте снова через кнопку «Примерить» в канале."
        )
        await state.clear()
        return

    product = PRODUCTS.get(product_id, {})
    garment_des = product.get("title") or "clothes"

    await message.answer("Фото получил, начинаю примерку через OOTDiffusion. Это может занять несколько минут...")

    try:
        merch_bytes = await download_file_bytes(merch_file_id)
        user_bytes = await download_file_bytes(file_id)
    except Exception as e:
        await message.answer(f"Ошибка при загрузке файлов из Telegram: {e}")
        await state.clear()
        return

    try:
        # call_ai_try_on — синхронная функция, запускаем её в отдельном потоке
        result_bytes = await asyncio.to_thread(
            call_ai_try_on,
            merch_bytes,
            user_bytes,
            garment_des,
        )
    except Exception as e:
        text = str(e)
        if "timed out" in text.lower():
            await message.answer(
                "Сервис примерки (OOTDiffusion на Hugging Face) слишком долго обрабатывает запрос "
                "или сейчас перегружен.\n"
                "Попробуйте ещё раз через несколько минут."
            )
        else:
            await message.answer(f"Произошла ошибка при генерации: {e}")
        await state.clear()
        return

    try:
        # отправляем пользователю скачанное изображение
        img_file = BufferedInputFile(result_bytes, filename=f"tryon_{product_id}.png")
        await message.answer_photo(
            photo=img_file,
            caption="Готово! Вот вы в этом мерче.",
        )
    except Exception as e:
        await message.answer(f"Не удалось отправить результат: {e}")
    finally:
        await state.clear()


# ===================== ТОЧКА ВХОДА =====================

async def main():
    print("Бот запущен, ожидаю сообщения...")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())