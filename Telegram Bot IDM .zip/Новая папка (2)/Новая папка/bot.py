import os
os.environ["GRADIO_CLIENT_TIMEOUT"] = "1200"

from gradio_client import Client, handle_file as gradio_file

client = Client("levihsu/OOTDiffusion")

# Положи рядом с этим скриптом два файла:
# - user.jpg  (фото человека)
# - cloth.jpg (фото одежды)
USER_PATH = "user.jpg"
CLOTH_PATH = "cloth.jpg"

try:
    result = client.predict(
        vton_img=gradio_file(USER_PATH),
        garm_img=gradio_file(CLOTH_PATH),
        category="Upper-body",
        n_samples=1,
        n_steps=20,
        image_scale=2,
        seed=-1,
        api_name="/process_dc",
    )
    print("RESULT:", result)
except Exception as e:
    print("ERROR:", repr(e))